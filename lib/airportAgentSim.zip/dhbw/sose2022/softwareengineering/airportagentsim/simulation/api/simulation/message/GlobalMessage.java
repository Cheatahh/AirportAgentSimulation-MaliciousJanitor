package dhbw.sose2022.softwareengineering.airportagentsim.simulation.api.simulation.message;

public non-sealed interface GlobalMessage extends Message {
	
}
