package dhbw.sose2022.softwareengineering.airportagentsim.simulation.api.simulation.entity;

public abstract class Agent extends MovingEntity {
	
	public Agent() {}
	
}
