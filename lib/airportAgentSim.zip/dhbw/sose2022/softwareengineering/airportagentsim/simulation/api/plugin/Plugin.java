package dhbw.sose2022.softwareengineering.airportagentsim.simulation.api.plugin;

public interface Plugin {
	
	public void activate();
	
}
