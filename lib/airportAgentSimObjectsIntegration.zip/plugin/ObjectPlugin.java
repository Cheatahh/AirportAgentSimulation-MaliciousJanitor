package plugin;

public class ObjectPlugin implements dhbw.sose2022.softwareengineering.airportagentsim.simulation.api.plugin.Plugin {

    @Override
    public void activate() {

    }
}
